import unittest
from app import flac_streaminfo, quality_allowed, is_hires

class ProtocolTests(unittest.TestCase):
    def test_empty_flac_header_rejected(self):
        self.assertEqual(flac_streaminfo(b"notflac"), {})

    def test_quality_filter_does_not_promote_lossy(self):
        self.assertFalse(quality_allowed({"lossless": False}, "lossless"))
        self.assertTrue(quality_allowed({"lossless": False}, "high"))

    def test_unknown_flac_not_claimed_hires(self):
        self.assertFalse(is_hires({"lossless": True}))

if __name__ == "__main__":
    unittest.main()
