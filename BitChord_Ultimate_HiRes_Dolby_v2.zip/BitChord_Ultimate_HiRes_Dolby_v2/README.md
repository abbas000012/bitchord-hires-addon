# BitChord Ultimate Hi-Res + Dolby — v2.0

A BitChord HTTP addon starter, updated to the current BitChord addon protocol.

## What is genuinely implemented
- Current `/manifest.json`, `/search`, and `/stream/{id}` response shapes.
- Quality picker: Max, verified Hi-Res lossless, Lossless, and High lossy.
- Local library support for FLAC, WAV, MP3, AAC, M4A, Ogg and Opus.
- FLAC STREAMINFO parsing: sample rate, bit depth and channels are reported only when actually read from the FLAC header.
- WAV metadata from the actual file header.
- Internet Archive search for actual FLAC files, conservatively limited to records with a recognized Creative Commons or public-domain rights marker.
- Optional `catalog.json` adapter for user-owned or licensed provider stream URLs, including real Dolby Atmos DASH/E-AC-3 JOC entries.
- Optional official BitChord 1.9.1 request-auth verification. It is enabled only after `BITCHORD_HOST` is configured.

## Dolby: honest capability boundary
BitChord sends `atmos=auto` only when Dolby is enabled and the device supports it. This addon prioritizes an Atmos row only when an authorized catalogue entry explicitly supplies a real Dolby stream and metadata such as `audioMode: "DOLBY_ATMOS"` and `codec: "eac3-joc"`.
Internet Archive FLAC search does not magically create or discover Atmos mixes. No Dolby content is bundled. Dolby Atmos is immersive and lossy in the documented E-AC-3 JOC path; it is not labelled bit-exact lossless.
Virtual surround processing is NOT performed by an HTTP addon. It needs a player DSP, Android audio effect, or compatible external device. This addon cannot change system-wide audio output.
Dolby TrueHD is not advertised as supported by this project; the documented BitChord Atmos path is DASH with E-AC-3 JOC. TrueHD needs separate player/decoder and device validation.

## Audio quality rules
- `hires` only returns a lossless source with verified bit depth above 16 or sample rate above 44.1 kHz.
- `lossless` returns FLAC, ALAC or PCM/WAV sources.
- `high` returns lossy formats.
- `max` prefers the best available source.
- Unknown metadata is omitted. A FLAC container does not prove that the recording was mastered from a high-resolution original.
- LDAC/LHDC are high-bitrate lossy Bluetooth codecs, not bit-perfect. Use wired USB DAC / HDMI for bit-exact playback.

## Run locally
Python 3.10+:

```bash
python -m venv .venv
# Windows
.venv\Scripts\activate
# macOS/Linux
source .venv/bin/activate
pip install -r requirements.txt
python app.py
```

Check:
- `http://127.0.0.1:8080/manifest.json`
- `http://127.0.0.1:8080/health`

Put only audio files you own or are authorized to use in `music/`.

## Dolby/provider catalogue adapter
Copy `catalog.json.example` to `catalog.json`. Add only stream URLs supplied by a provider you are authorized to use, or URLs to content you own. Example entry:

```json
[
  {
    "id": "licensed-atmos-demo",
    "title": "Example Atmos mix",
    "artist": "Example artist",
    "album": "Example album",
    "duration": 210,
    "url": "https://provider.example/path/manifest.mpd",
    "format": "dash",
    "container": "mp4",
    "manifest": "dash",
    "codec": "eac3-joc",
    "audioMode": "DOLBY_ATMOS",
    "sampleRate": 48000,
    "encrypted": false
  }
]
```

This is a schema example only, not a working media URL. Do not paste paid-service URLs, DRM-protected URLs, cookies, or account tokens into a public deployment. The player refuses protected streams.

## Official BitChord addon authentication (1.9.1+)
The manifest declares `bitchordAuth: true` only after both the official verifier dependency file is present and `BITCHORD_HOST` is set. This avoids falsely claiming protection.
The official verifier is maintained by BitChord:
https://bitchord.kushagrasingh.in/addon-auth/bitchord_addon_auth.py

Download that file unchanged into the project root, then:
```bash
pip install cryptography
```
Set `BITCHORD_HOST` to the exact hostname only, e.g. `my-service.onrender.com` (no scheme, path, or port). The manifest remains public; `/search` and `/stream` are verified.
Until this is configured, the addon still works but BitChord may show its “Outdated addon” notice.

## Deploy
1. Push this project to a private or public GitHub repository. Do not commit private music files or catalog URLs containing secrets.
2. Deploy as a Python web service on a host that supports Flask and persistent storage.
3. Build command: `pip install -r requirements.txt`
4. Start command: `gunicorn app:app`
5. Set `BITCHORD_HOST` after the host gives you its public hostname; add the official verifier file as described above.
6. Add the HTTPS manifest URL in BitChord → Settings → Sources → Add an addon.

Free host plans and storage limits change. A sleeping free host may take time to wake. Ephemeral disk is not a permanent music library.

## Current protocol reference
https://bitchord.kushagrasingh.in/docs

The addon does not unlock commercial streaming catalogues or bypass DRM. Use only content and providers you are entitled to access.
